
import React from 'react';

function App() {
  return (
    <div className="App">
      <h1>Doctor Appointment Booking App</h1>
    </div>
  );
}

export default App;
